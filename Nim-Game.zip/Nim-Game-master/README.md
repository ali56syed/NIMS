# Nim-Game
Android App for playing the Game of Nims.

