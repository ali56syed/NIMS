package me.arnavgarg.nimgame.Game;

/**
 * Created by Arnav on 4/8/2016.
 */
public abstract class GameDifficultyMain {

    //An abstract method to parent all the three difficulty levels! :)

    public abstract int[] computerTurn(int[] a);
}
